## How to install

Copy the `DesignSystem` resource package folder and paste
into your `ProjectName / ResourcePackage` folder and rebuild the project.

The **Sitefinity DesignSystem (sgds)** resource package include:
1. sgds stylesheet 
    `/DesignSystem/assets/dist/css/sgds.css`

2. sgds javascript file 
    `/DesignSystem/assets/dist/js/sgds.js`

3. sgds icon library 
    `/DesignSystem/assets/dist/fonts/`

4. sgds grid system template `/DesignSystem/GridSystem/Templates/`
   * section template `sgds-section.html`
   * container template `sgds-container.html`
   * grid columns `sgds-grid-x.html`

5. Master layout with the DSS compliant Mandatory components `DesignSystem/MVC/Views/Layouts/`
    * Gov.sg masthead
    * Navigation bar widget 
    `/DesignSystem/MVC/Views/Navigation/NavigationView.sgds.cshtml`
    * Footer
