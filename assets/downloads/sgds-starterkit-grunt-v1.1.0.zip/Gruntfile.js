module.exports = function(grunt) {
    require('load-grunt-tasks')(grunt);

    grunt.initConfig({
        clean: {
            build: {
                src: [ "build" ]
            }
        },
        copy: {
            build: {
                options: {},
                files: [{
                    cwd: 'src',
                    src: [ '**', '!scss/**' ],
                    dest: 'build',
                    expand: true
                }]
            },
            sgds_govtech:{
                options:{},
                files: [{
                    cwd: 'node_modules/sgds-govtech',
                    src: [ 'js/*.js','fonts/**'],
                    dest: 'src',
                    expand: true
                }]
            },
            jquery:{
                options:{},
                files: [{
                    cwd: 'node_modules',
                    src: [ 'jquery/dist/jquery.min.js'],
                    dest: 'src/js',
                    expand: true
                }]
            }
        },
        sass: {
            dist: {
                options: {
                    style: 'expanded'
                },
                files: {
                    'build/css/main.css': 'src/scss/main.scss'
                }
            }
        },
        connect: {
            server: {
                options: {
                    livereload: true,
                    hostname: '0.0.0.0',
                    port: 9000,
                    base: 'build'
                }
            }
        },

        watch: {
            sass: {
                files: ['src/css/main.scss'],
                tasks: ['sass'],
                options: {
                    livereload: true
                }
            },
            img:{
                files: ['src/**/*{.jpg,.png,.svg}'],
                tasks: ['copy:build'],
                options: {
                    livereload: true
                }
            },
            html:{
                files: 'src/*.html',
                tasks: ['copy:build'],
                options: {
                    livereload: true
                },
            }
        },
        zip: {
            '../blueprint-jekyll/assets/downloads/sgds-starterkit-grunt-v1.1.0.zip': ['src/img', 'src/scss', '*.html', 'package.json', 'README.md','Gruntfile.js','.gitignore']
        }
    });

    grunt.registerTask('dev', [ 'clean:build','copy:sgds_govtech','copy:jquery','copy:build', 'sass','connect', 'watch' ] );
};