## SGDS Starter Kit for GRUNT

How to use:

1. Install Grunt-cli `npm install -g grunt-cli`, install 
2. Clone the repository
3. Open your preferred IDE and navigate to the cloned folder
4. Do a `npm install`
5. Run `grunt dev `
6. Open your browser with this url `http://localhost:9000`