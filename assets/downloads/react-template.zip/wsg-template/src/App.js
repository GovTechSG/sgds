import "@govtechsg/sgds/css/sgds.css";
import "@govtechsg/sgds-masthead/dist/sgds-masthead/sgds-masthead.css";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import { NavbarTemp } from "./components/NavbarTemp";
import { SinglePageFormTemp } from "./components/SinglePageFormTemp";
import { LandingPageTemp } from "./components/LandingPageTemp";
import { DetailPageSideNavExtTemp } from "./components/DetailPageSideNavExtTemp";
import { SgdsMasthead } from "@govtechsg/sgds-masthead-react";

function App() {
  return (
    <>
      <SgdsMasthead fluid />
      <Router>
        <div className='mb-3'>
          <NavbarTemp />
        </div>
        <Routes>
          <Route path='/' element={<LandingPageTemp />} />
          <Route path='/singlepage' element={<SinglePageFormTemp />} />
          <Route
            path='/detailpage-sidenavext'
            element={<DetailPageSideNavExtTemp />}
          />
        </Routes>
      </Router>
    </>
  );
}
export default App;
