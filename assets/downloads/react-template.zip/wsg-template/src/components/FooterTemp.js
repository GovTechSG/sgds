import { Footer } from "@govtechsg/sgds-react";
import React from "react";
import { Link } from "react-router-dom";

export const FooterTemp = (args) => {
  return (
    <Footer>
      <Footer.Top>
        <Footer.Top.ContactLinks>
          <Link to='' target='_blank'>
            Contact Us
          </Link>
          <Link to='' target='_blank'>
            Feedback
          </Link>
        </Footer.Top.ContactLinks>
      </Footer.Top>
      <Footer.Bottom>
        <Footer.Bottom.Links>
          <Link to='' target='_blank'>
            Report Vulnerability
          </Link>
          <Link to=''>Privacy</Link>
          <Link to=''>Terms of use</Link>
        </Footer.Bottom.Links>
        <Footer.Bottom.Copyrights className='text-end'>
          © 2022 Government of Singapore. Last Updated 08 Feb 2022
        </Footer.Bottom.Copyrights>
      </Footer.Bottom>
    </Footer>
  );
};
