import React, { useState } from "react";
import { SideNav } from "@govtechsg/sgds-react/SideNav";

export const SideNavTemp = (args) => {
  const [sideActive, setSideActive] = useState("1");

  const clickSideNavItem = (eventKey) => {
    setSideActive(eventKey);
  };

  const [sideActiveLink, setSideActiveLink] = useState("1.1");

  const clickSideNavLink = (eventKey) => {
    setSideActiveLink(eventKey);
  };
  return (
    <SideNav activeKey={sideActive} activeNavLinkKey={sideActiveLink}>
      <SideNav.Item eventKey='1' onClick={() => clickSideNavItem("1")}>
        <SideNav.Button>Sub menu</SideNav.Button>
        <SideNav.Collapse>
          <SideNav.Link
            eventKey='1.1'
            href='/'
            onClick={() => clickSideNavLink("1.1")}
          >
            Sub menu item
          </SideNav.Link>
          <SideNav.Link
            eventKey='1.2'
            href='/'
            onClick={() => clickSideNavLink("1.2")}
          >
            Sub menu item
          </SideNav.Link>
          <SideNav.Link
            eventKey='1.3'
            href='/'
            onClick={() => clickSideNavLink("1.3")}
          >
            Sub menu item
          </SideNav.Link>
        </SideNav.Collapse>
      </SideNav.Item>
      <SideNav.Item eventKey='2' onClick={() => clickSideNavItem("2")}>
        <SideNav.Button>Sub menu</SideNav.Button>
        <SideNav.Collapse>
          <SideNav.Link
            eventKey='2.1'
            href='/'
            onClick={() => clickSideNavLink("2.1")}
          >
            Sub menu item
          </SideNav.Link>
          <SideNav.Link
            eventKey='2.2'
            href='/'
            onClick={() => clickSideNavLink("2.2")}
          >
            Sub menu item
          </SideNav.Link>
          <SideNav.Link
            eventKey='2.3'
            href='/'
            onClick={() => clickSideNavLink("2.3")}
          >
            Sub menu item
          </SideNav.Link>
        </SideNav.Collapse>
      </SideNav.Item>
      <SideNav.Item eventKey='3' onClick={() => clickSideNavItem("3")}>
        <SideNav.Button>Sub menu</SideNav.Button>
        <SideNav.Collapse>
          <SideNav.Link
            eventKey='3.1'
            href='/'
            onClick={() => clickSideNavLink("3.1")}
          >
            Sub menu item
          </SideNav.Link>
          <SideNav.Link
            eventKey='3.2'
            href='/'
            onClick={() => clickSideNavLink("3.2")}
          >
            Sub menu item
          </SideNav.Link>
          <SideNav.Link
            eventKey='3.3'
            href='/'
            onClick={() => clickSideNavLink("3.3")}
          >
            Sub menu item
          </SideNav.Link>
        </SideNav.Collapse>
      </SideNav.Item>
    </SideNav>
  );
};
