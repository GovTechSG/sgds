import React from "react";
import { Breadcrumb } from "@govtechsg/sgds-react/Breadcrumb";
import { Row } from "@govtechsg/sgds-react/Row";
import { Col } from "@govtechsg/sgds-react/Col";
import { FooterTemp } from "./FooterTemp.js";
import { SideNavTemp } from "./SideNavTemp.js";

export const DetailPageSideNavExtTemp = (args) => {
  return (
    <>
      <Row className='m-8'>
        <Col lg='3' className='d-none d-lg-block'>
          <SideNavTemp />
        </Col>
        <Col lg='7'>
          <Breadcrumb className='mb-8'>
            <Breadcrumb.Item href=''>Home</Breadcrumb.Item>
            <Breadcrumb.Item href=''>Library</Breadcrumb.Item>
            <Breadcrumb.Item active>Data</Breadcrumb.Item>
          </Breadcrumb>
          <h2>Page heading</h2>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
            eiusmod tempor incididunt ut labore et dolore magna aliqua.
          </p>
          <h4>Overview</h4>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
            eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim
            ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut
            aliquip ex ea commodo consequat. Duis aute irure dolor in
            reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
            pariatur.
          </p>
        </Col>
        <Col lg='2' className='d-none d-lg-block'>
          <h4>On this page</h4>
          <ul
            style={{
              listStyle: "none",
            }}
          >
            <li>
              <a href='#' className='text-decoration-none'>
                Page heading
              </a>
            </li>
            <ul
              style={{
                listStyle: "none",
              }}
            >
              <li>
                <a href='#' className='text-decoration-none'>
                  Overview
                </a>
              </li>
            </ul>
          </ul>
        </Col>
      </Row>
      <FooterTemp
      />
    </>
  );
};
