#**sgds-Govtech**
sgds is a reusable and upgradable frontend framework that aims to provide tools for the government agencies to comply with the latest policies for websites and digital services easily.

## Installation
```console
npm i sgds-govtech
```

## Patch Notes